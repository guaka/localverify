DERIVED TEST DATA ONLY — not a device acquisition or exploit payload.
Publicly reported process names and timestamps are minimally reconstructed for parser testing.
